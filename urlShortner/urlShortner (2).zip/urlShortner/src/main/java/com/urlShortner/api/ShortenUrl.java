package com.urlShortner.api;

public class ShortenUrl {

	private String full_url;
	private String short_url;

	public String getFull_url() {
		System.out.println("ShortenUrl.getFull_url()");
		return full_url;
	}

	public void setFull_url(String full_url) {
		System.out.println("ShortenUrl.setFull_url");
		this.full_url = full_url;
	}

	public String getShort_url() {
		System.out.println("gShortenUrl.etShort_url");
		return short_url;
	}

	public void setShort_url(String short_url) {
		System.out.println("ShortenUrl.setShort_url()");
		this.short_url = short_url;
	}

}
