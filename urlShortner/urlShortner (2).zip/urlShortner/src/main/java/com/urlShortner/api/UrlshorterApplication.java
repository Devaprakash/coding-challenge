package com.urlShortner.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrlshorterApplication {

	public static void main(String[] args) {
		System.out.println("UrlshorterApplication.main");
		SpringApplication.run(UrlshorterApplication.class, args);
	}

}
