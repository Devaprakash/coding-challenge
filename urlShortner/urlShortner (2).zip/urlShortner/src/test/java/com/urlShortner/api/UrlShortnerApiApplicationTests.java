package com.urlShortner.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlShortnerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
